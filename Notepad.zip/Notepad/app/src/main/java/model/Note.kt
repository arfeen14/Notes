package model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
import java.util.*

@Parcelize
@Entity
data class Note(
    @ColumnInfo(name = "title")
    var title: String,
    @ColumnInfo(name = "lastUpdated")
    var lastUpdated: Date,
    @ColumnInfo(name = "text")
    var text: String,
    @PrimaryKey
    @ColumnInfo(name = "id")
    var id: Long? = null
) : Parcelable


//@COluminfo is onnodig in mijn geval maar doe het zodat ik het voor mezelfduidelijk maak dat je het kan doen