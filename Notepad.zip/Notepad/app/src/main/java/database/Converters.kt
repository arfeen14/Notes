package database

import androidx.room.TypeConverter
import java.util.*

class Converters {
//forward conversion
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return if (value == null) null else Date(value)
    }

    //backwards conversion
    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}